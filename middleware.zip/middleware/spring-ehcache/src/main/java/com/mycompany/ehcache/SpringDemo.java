package com.mycompany.ehcache;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringDemo {
	public static void main(String... args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.register(AppConfig.class);
		ctx.refresh();
		Employee employee = (Employee) ctx.getBean(Employee.class);

		// calling getEmployee method first time.
		System.out.println("---Fetch Employee with id 1---");
		System.out.println("Employee:" + employee.getEmployee(1));

		// calling getEmployee method second time. This time, method will not
		// execute.
		System.out
				.println("---Again Fetch Employee with id 1, result will be fetched from cache---");
		System.out.println("Employee:" + employee.getEmployee(1));

		// calling getEmployee method third time with different value.
		System.out.println("---Fetch Employee with id 2---");
		System.out.println("Employee:" + employee.getEmployee(2));

		ctx.close();
	}
}