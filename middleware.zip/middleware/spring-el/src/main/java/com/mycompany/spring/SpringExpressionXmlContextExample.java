package com.mycompany.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringExpressionXmlContextExample {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		try {
			Training training = (Training) context.getBean("training");
			System.out.println(training.getTopic());

			System.out.println(training.getDefaultTopic());
		} finally {
			context.close();
		}
	}
}
