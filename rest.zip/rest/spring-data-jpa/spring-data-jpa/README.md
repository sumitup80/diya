Example of Spring Data JPA application (Hibernate used as implementation of JPA).
