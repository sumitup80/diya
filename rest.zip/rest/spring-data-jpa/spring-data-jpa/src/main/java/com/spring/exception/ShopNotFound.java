package com.spring.exception;

public class ShopNotFound extends Exception {

}
