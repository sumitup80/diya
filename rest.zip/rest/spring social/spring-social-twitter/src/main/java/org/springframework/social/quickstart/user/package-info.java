/**
 * A simple user authentication model supporting the quickstart application.
 */
package org.springframework.social.quickstart.user;

