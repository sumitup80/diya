/**
 * Configures the quickstart application.
 */
package org.springframework.social.quickstart.config;

