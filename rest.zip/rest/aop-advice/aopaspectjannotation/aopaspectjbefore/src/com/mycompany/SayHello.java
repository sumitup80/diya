package com.mycompany;

public class SayHello {

	public void hello(){
		
		System.out.println("Hi there");
	}
}
