package com.training.validators;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.training.bean.Book;

@Component
public class BookValidator implements Validator {

	//specifies which class can use this validator
	@Override
	public boolean supports(Class<?> myclass) {
		return Book.class.equals(myclass);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		/*configure in resource bundle*/
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "isbn", "isbn.required");
		Book book=(Book)obj;
		if(book.getPrice()<=0){
			errors.rejectValue("price","price.value",
					new Object[]{"'Price'"}, "can't be negative");
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"title", "title.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"author", "author.required");
		if(book.getCategory()==null){
			errors.rejectValue("category","category.select", 
					new Object[]{"'category'"}, "must be selected");
		}
	}

}
