package com.training.dao;

import java.util.List;

import com.training.bean.Book;

public interface BookDAO {

	void addBook(Book book);

	List<Book> getAllBooks();

	Book getBookByID(Integer bookID);

	boolean editBook(Book book);

	List<Book> searchBook(String searchkey);
}
