package com.training.dao.impl;

import java.util.List;



import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.training.bean.Book;
import com.training.dao.BookDAO;
import com.training.service.impl.BookServiceImpl;

@Repository
public class BookDAOImpl implements BookDAO {
	Logger logger = Logger.getLogger(BookServiceImpl.class);
	
	@Autowired
	private SessionFactory factory;
	
	public SessionFactory getFactory() {
		return factory;
	}

	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		logger.info("Adding a book in BookDAOImpl");
		session.save(book);
		transaction.commit();
		session.close();
	}

	@Override
	public List<Book> searchBook(String searchkey) {
		
		BasicConfigurator.configure();
		logger.info("Getting books by Author in BookDAOImpl");
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
String query1 = "from Book b where b.author like :auth or b.title like :title or"
				+ "  b.category like :category";
		Query query = session.createQuery(query1);
		query.setString("auth", "%"+searchkey+"%");
		query.setString("title", "%"+searchkey+"%");
		query.setString("category", "%"+searchkey+"%");
		List<Book> bookList = query.list();
		logger.info("Getting all books in BookDAOImpl");
		System.out.println(bookList);
		transaction.commit();
		return bookList;
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Book");
		List<Book> bookList = query.list();
		logger.info("Getting all books in BookDAOImpl");
		transaction.commit();
		return bookList;
	}

	
	@Override
	public Book getBookByID(Integer bookID) {
		
		BasicConfigurator.configure();
		logger.info("Getting books by bookID in BookDAOImpl");
		Session session = factory.openSession();
		Book book = (Book) session.get(Book.class, bookID);
		return book;
	}

	@Override
	public boolean editBook(Book book) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		logger.info("Editing a book in BookDAOImpl");
		System.out.println(book);
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(book);
		transaction.commit();
		return true;
	}

}
