package com.training.service;

import java.util.List;

import com.training.bean.Book;

public interface BookService {
	
	void addBook(Book book);
	List<Book> getAllBooks();
	List<Book> searchBook(String searchkey);
	Book getBookByID(Integer bookID);
	boolean editBook(Book book);
}
