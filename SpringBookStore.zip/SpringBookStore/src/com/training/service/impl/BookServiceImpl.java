package com.training.service.impl;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.bean.Book;
import com.training.dao.BookDAO;
import com.training.service.BookService;

@Service
@Transactional
public class BookServiceImpl implements BookService {
	Logger logger = Logger.getLogger(BookServiceImpl.class);
	
	@Autowired
	BookDAO bookDAO;
	
	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		bookDAO.addBook(book);
	}
	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		return bookDAO.getAllBooks();
	}
	@Override
	public Book getBookByID(Integer bookID) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		return bookDAO.getBookByID(bookID);
	}

	@Override
	public boolean editBook(Book book) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		return bookDAO.editBook(book);
	}

	@Override
	public List<Book> searchBook(String searchkey) {
		BasicConfigurator.configure();
		return bookDAO.searchBook(searchkey);
	}

}
