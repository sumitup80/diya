package com.training.controller;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller

public class UserController {
	
Logger logger = Logger.getLogger(BookController.class);
	
	@RequestMapping("/userlogin")
	public String showUserLogin(){
		return "userlogin";
	}
	
	@RequestMapping("/checkCredentials")
	public String checkCredentials(ModelMap map, @RequestParam("username")String userName, @RequestParam("password")String password){
		if(userName.equals("admin") && password.equals("admin")){
			return "admin";
		}else {
			return "redirect:/";
			}
		
		
	}
	
	
}
