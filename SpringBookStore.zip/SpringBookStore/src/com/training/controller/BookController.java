package com.training.controller;



import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.training.bean.Book;
import com.training.service.BookService;

@Controller
public class BookController {
	
	Logger logger = Logger.getLogger(BookController.class);
	
	@RequestMapping("/")
	public String showHomePage(ModelMap map){
		/*ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		BookService service = (BookService)context.getBean("bookServiceImpl");
		List<Book> bookList = service.getAllBooks();
		map.addAttribute("bookList",bookList);*/
		return "home";
	}
	
	@RequestMapping("/showaddBookForm")
	public String showBookForm(ModelMap map){
		Book book = new Book();
		map.addAttribute("book",book);
		return "addbook";
	}
	
	@RequestMapping("/addBook")
	public String addBookSubmit(@ModelAttribute("book")@Valid Book book, BindingResult result){
		System.out.println(book);
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		BookService service = (BookService)context.getBean("bookServiceImpl");
		service.addBook(book);
		return "addBookSuccess";
	}

	@RequestMapping("/showeditBookForm")
	public String showEditBookForm(ModelMap map){
		Book book = new Book();
		map.addAttribute("book",book);
		return "editBookForm";
	}
	
	@RequestMapping("/editBookSubmit")
	public String editCarSubmit(@ModelAttribute("bookID") @Valid String bookID,ModelMap map, BindingResult result ){
		System.out.println(bookID);
		if(result.hasErrors()){
			return "editBookForm";
		}
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		BookService service = (BookService)context.getBean("bookServiceImpl");
		Book book = service.getBookByID(Integer.parseInt(bookID));
		map.addAttribute("book",book);
		return "editBookDetails";
	}
	
	@RequestMapping("/editBookSuccess")
	public String editBookSuccess(@ModelAttribute("book")@Valid Book book, BindingResult result){
		System.out.println(book);
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		BookService service = (BookService)context.getBean("bookServiceImpl");
		boolean editResult = service.editBook(book);
		if(editResult != true){
			return "editBookDetails";
		}
		return "editBookSuccess";
	}
	@RequestMapping(value = "/search",headers="Accept=application/json")
	public String searchBook(@RequestParam("searchkey")String key,ModelMap map){
		//ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		//BookService service = (BookService)context.getBean("bookServiceImpl");
		
		System.out.println("hello");
		List<Book> bookList = new ArrayList<>();//service.searchBook(key);
		if(bookList.size()==0){
			RestTemplate template = new RestTemplate();
			String bookurl =
		"http://localhost:8001/Spring4RESTConsumer/search/"+key;
			bookList=template.getForObject(bookurl, List.class);
			System.out.println(bookList);
		}
		map.addAttribute("bookList",bookList);
		return "home";
	}
	
}
