package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


@Controller
//@RequestMapping(value={"/addemployee","/add"})
public class FormController {
	
	@RequestMapping("/checkhello")
	public String greetings(ModelMap map) {
		 map.addAttribute("mess","Using Model Attribute");
		return "welcome";
	}
	
	
	
	@RequestMapping("/checkdemo")
	public ModelAndView getMessage() {
		String message = "welcome to spring using model and view";
		return new ModelAndView("final", "myoutput", message);
	}
	
	
	@RequestMapping("/greet")
	public String greet() {
		 return "hello";
	}

}
