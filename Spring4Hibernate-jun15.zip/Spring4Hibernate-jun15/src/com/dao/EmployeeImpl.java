package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Employee;
@Repository
public class EmployeeImpl implements EmployeeDAO {

	@Autowired
	private SessionFactory factory;
	
		
	public SessionFactory getFactory() {
	return factory;
}

public void setFactory(SessionFactory factory) {
	this.factory = factory;
}

	@Override
	public Integer addEmployee(Employee e) {
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Integer v = (Integer) session.save(e);
		System.out.println("In DAO");
		t.commit();
		return v;
	}

	@Override
	public List<Employee> getallEmployees() {
		Session session = factory.openSession();
		Query query = session.createQuery("from Employee");
		List<Employee> empList = (List<Employee>)query.list();
		return empList;
		
		
	}
	@Override
	public List<Employee> getEmployeesByCity(String city) {
		Session session = factory.openSession();
		String mquery = "from Employee e where e.city like :mcity";
		Query query = session.createQuery(mquery);
		query.setString("mcity", city);
		List<Employee> mylist =
				(List<Employee>) query.list();
		return mylist;
	}
	
	
}
