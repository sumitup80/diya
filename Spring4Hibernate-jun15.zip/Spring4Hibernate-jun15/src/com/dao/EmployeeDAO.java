package com.dao;

import java.util.List;

import com.bean.Employee;

public interface EmployeeDAO {
	Integer addEmployee(Employee e);
	List<Employee> getallEmployees();
	List<Employee> getEmployeesByCity(String city);

}
