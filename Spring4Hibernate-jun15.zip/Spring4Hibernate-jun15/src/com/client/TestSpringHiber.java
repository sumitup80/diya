package com.client;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bean.Employee;
import com.service.EmployeeService;
import com.service.EmployeeServiceImpl;

public class TestSpringHiber {
	
	public static void main(String[] args) {
	
		Employee emp = new Employee();
		emp.setId(180);
		emp.setCity("Chennai");
		emp.setName("Amala");
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("springhiber.xml");
		EmployeeService empl = 
				(EmployeeService)context.getBean("employeeServiceImpl");
		Integer result = empl.addEmployee(emp);
		ArrayList<Employee> list = (ArrayList<Employee>)empl.getAllEmployees();
		for (Employee e : list) {
			System.out.println(e);
		}
		list = (ArrayList<Employee>)empl.getEmployeesByCity("Chennai");
		for (Employee e : list) {
			System.out.println(e);
		}
		
	}

}
