package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.bean.Employee;
import com.dao.EmployeeDAO;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDAO employeeDAO;
	
	@Override
	public Integer addEmployee(Employee e) {
		Integer id = employeeDAO.addEmployee(e);
		System.out.println("in service");
		return id;
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> list = employeeDAO.getallEmployees();
		return list;
	}

	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	@Override
	public List<Employee> getEmployeesByCity(String city) {
		List<Employee> list = employeeDAO.getEmployeesByCity(city);
		return list;
	}

		
	

}
