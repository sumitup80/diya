package com.service;

import java.util.List;

import com.bean.Employee;


public interface EmployeeService {
	
	Integer addEmployee(Employee e);
	List<Employee> getAllEmployees();
	List<Employee> getEmployeesByCity(String city);
	
	

}
