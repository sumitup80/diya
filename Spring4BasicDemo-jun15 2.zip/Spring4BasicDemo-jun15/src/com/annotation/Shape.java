package com.annotation;

public interface Shape {

	double area(int x, int y);
}
