package com.autowire;

public class Circle  implements Shape{

	@Override
	public double area(int x,int y) {
		return 3.14 *x;
		
	}
	
}


