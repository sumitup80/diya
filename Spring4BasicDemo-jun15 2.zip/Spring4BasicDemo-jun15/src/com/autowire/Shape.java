package com.autowire;

public interface Shape {

	double area(int x,int y);
}
