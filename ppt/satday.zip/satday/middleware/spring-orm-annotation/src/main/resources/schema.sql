CREATE TABLE  `mycompany`.`EMPLOYEE` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(64) NOT NULL,
  `SSN` varchar(64) NOT NULL,
  `JOINING_DATE` datetime,
   `SALARY` decimal,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;