package com.mycompany.common;

public class App {
	public static void main(String[] args) {
		// ...

	}
}
