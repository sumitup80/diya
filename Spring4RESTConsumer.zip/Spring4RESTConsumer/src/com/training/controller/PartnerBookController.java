package com.training.controller;



import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.bean.Book;
import com.training.service.PartnerBookService;

@RestController
public class PartnerBookController {
	
	Logger logger = Logger.getLogger(PartnerBookController.class);
	
	
	@RequestMapping(value="/search/{key}",
	method = RequestMethod.GET,headers="Accept=application/json")
	public  List<Book> searchBook(@PathVariable("key") String searchkey,ModelMap map){
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		PartnerBookService service = (PartnerBookService)context.getBean("partnerBookServiceImpl");
		List<Book> bookList = service.searchBook(searchkey);
		map.addAttribute("bookList",bookList);
		return bookList;
	}
	
	
}
