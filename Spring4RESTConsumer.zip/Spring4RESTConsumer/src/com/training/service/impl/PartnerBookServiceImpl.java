package com.training.service.impl;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.bean.Book;
import com.training.dao.PartnerBookDAO;
import com.training.service.PartnerBookService;

@Service
@Transactional
public class PartnerBookServiceImpl implements PartnerBookService {
	Logger logger = Logger.getLogger(PartnerBookServiceImpl.class);
	
	@Autowired
	PartnerBookDAO bookDAO;
	
	@Override
	public List<Book> searchBook(String searchkey) {
		BasicConfigurator.configure();
		return bookDAO.searchBook(searchkey);
	}

}
