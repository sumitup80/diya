package com.training.service;

import java.util.List;

import com.training.bean.Book;

public interface PartnerBookService {
	
	List<Book> searchBook(String searchkey);
	
}
