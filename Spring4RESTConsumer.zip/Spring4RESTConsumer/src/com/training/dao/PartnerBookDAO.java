package com.training.dao;

import java.util.List;

import com.training.bean.Book;

public interface PartnerBookDAO {

	List<Book> searchBook(String key);


}
